# QuantBlocks — Redesign Port

Drop-in replacement files for the existing QuantBlocks codebase. Apply by copying the contents of `src/` and the root `tailwind.config.ts` over your project (back up first).

## What changed

- **Light theme migration** — TradingView-inspired clean light surface with `#2962ff` accent. CSS variables + tokens in `globals.css`. `tailwind.config.ts` extended.
- **Strategy list (`/strategies`)** — Inline "+ New Strategy" create flow that POSTs to `/api/strategies` and routes to the new strategy. Cards show metadata cleanly.
- **Strategy workspace** — Tighter layout: brand header, drag-and-drop node palette on the left, React Flow canvas in the middle, resizable + collapsible bottom drawer for Backtest/Paper Trading.
- **Node Palette (new component)** — Categorized (Data / Indicators / Logic / Actions), drag onto canvas via React Flow's native dnd, or click to add at center.
- **AI Builder** — Now a floating panel triggered from the canvas toolbar, not a permanent sidebar. ⌘↵ to generate.
- **Bottom drawer** — Resize handle, collapse to title bar. Backtest and Paper Trading tabs preserved.
- **Node visual style** — BaseNode now renders a colored category header bar; form controls re-styled for light surface via shared `.node-*` utility classes in `globals.css`. All node files updated.

## File map

```
src/app/globals.css                                   (updated — design tokens, light theme)
src/app/layout.tsx                                    (updated — light body, DM Sans font)
src/app/strategies/page.tsx                           (updated — create flow)
src/components/strategy/StrategyWorkspace.tsx         (rewritten)
src/components/strategy/NodePalette.tsx               (NEW)
src/components/strategy/StrategyCanvas.tsx            (updated — drop target, light theme)
src/components/strategy/AiPromptPanel.tsx             (rewritten — floating panel)
src/components/strategy/BacktestPanel.tsx             (updated — light theme + metric cards)
src/components/strategy/PaperTradingPanel.tsx         (updated — light theme)
src/components/strategy/nodeTypes/BaseNode.tsx        (rewritten — category color, ports)
src/components/strategy/nodeTypes/*.tsx               (updated — light-theme controls)
tailwind.config.ts                                    (updated — theme tokens)
```

## Install

```bash
# from project root
cp -R quantblocks-src/src/* src/
cp quantblocks-src/tailwind.config.ts ./
npm run dev
```

No new dependencies. All API contracts (`/api/strategies`, `/api/backtests`, `/api/paper`, `/api/ai/translateStrategy`) are preserved.

## Notes

- The `instrument` field is hard-coded to "BTC-PERP" in `POST /api/strategies`; the create form currently doesn't expose instrument/timeframe. Easy follow-up: add fields to the create form and pass them through.
- The palette uses React Flow's native HTML5 drag-and-drop — `StrategyCanvas` exposes `onDrop`/`onDragOver` handlers.
- Dark-theme classes inside node files (`bg-gray-800`, `text-gray-200`, etc.) have been replaced with `.node-input` / `.node-select` / `.node-chip` / `.node-chip-active` utility classes for consistency. If you reintroduce dark mode later, those four classes are the only place to flip.
