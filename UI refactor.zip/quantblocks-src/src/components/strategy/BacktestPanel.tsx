"use client";

import { useState, useCallback, useRef, useEffect } from "react";
import { TwoPaneChart } from "./TwoPaneChart";
import type { BarItem } from "./TwoPaneChart";

const POLL_INTERVAL_MS = 1500;

type EquityPoint = { time: string; equity: number };
type RunStatus = "idle" | "running" | "success" | "error";

type BacktestRun = {
  id: string;
  status: string;
  metrics?: Record<string, unknown> | null;
  log?: {
    equityCurve?: EquityPoint[];
    error?: string;
    initialCapital?: number;
  } | null;
  startTime?: string | null;
  endTime?: string | null;
};

type Trade = {
  id?: string;
  side: string;
  entryTime: string;
  entryPrice: number;
  exitTime: string | null;
  exitPrice: number | null;
  qty: number;
  pnl: number;
};

function formatTime(iso: string | null | undefined): string {
  if (iso == null || iso === "") return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" });
  } catch {
    return String(iso);
  }
}

function formatPct(value: unknown): string {
  if (typeof value !== "number" || !Number.isFinite(value)) return "—";
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function formatNum(value: unknown, digits = 2): string {
  if (typeof value !== "number" || !Number.isFinite(value)) return "—";
  return value.toLocaleString(undefined, { maximumFractionDigits: digits });
}

function MetricCard({
  label,
  value,
  positive,
}: {
  label: string;
  value: string;
  positive?: boolean | null;
}) {
  const tone =
    positive === true
      ? { bg: "var(--green-bg)", color: "var(--green)" }
      : positive === false
      ? { bg: "var(--red-bg)", color: "var(--red)" }
      : { bg: "var(--surface-2)", color: "var(--text-1)" };

  return (
    <div
      className="flex flex-col items-center rounded-lg px-3.5 py-2"
      style={{ background: tone.bg, minWidth: 76 }}
    >
      <span className="text-[9px] font-bold uppercase tracking-[0.08em] text-ink-3">
        {label}
      </span>
      <span
        className="mt-1 font-mono text-[15px] font-bold tabular-nums"
        style={{ color: tone.color }}
      >
        {value}
      </span>
    </div>
  );
}

function buildEquityCurveFromTrades(
  trades: Trade[],
  initialCapital: number
): EquityPoint[] {
  const closed = trades
    .filter((t) => t.exitTime != null)
    .sort(
      (a, b) =>
        new Date(a.exitTime!).getTime() - new Date(b.exitTime!).getTime()
    );
  if (closed.length === 0) return [];
  const earliestEntry = closed.reduce((best, t) =>
    new Date(t.entryTime).getTime() < new Date(best.entryTime).getTime()
      ? t
      : best
  );
  const curve: EquityPoint[] = [
    { time: earliestEntry.entryTime, equity: initialCapital },
  ];
  let equity = initialCapital;
  for (const t of closed) {
    equity += t.pnl;
    curve.push({ time: t.exitTime!, equity });
  }
  return curve;
}

function getInitialCapital(run: BacktestRun): number {
  const fromLog = run.log?.initialCapital;
  if (typeof fromLog === "number" && Number.isFinite(fromLog) && fromLog > 0) {
    return fromLog;
  }
  const totalReturnPct = run.metrics?.totalReturnPct as number | undefined;
  const netPnl = run.metrics?.netPnl as number | undefined;
  if (
    typeof totalReturnPct === "number" &&
    Number.isFinite(totalReturnPct) &&
    totalReturnPct !== 0 &&
    typeof netPnl === "number" &&
    Number.isFinite(netPnl)
  ) {
    const derived = (netPnl * 100) / totalReturnPct;
    if (Number.isFinite(derived) && derived > 0) return derived;
  }
  return 10_000;
}

function toChartEquity(
  curve: EquityPoint[]
): { time: number; value: number }[] {
  return curve
    .filter((p) => p.time != null && p.time !== "")
    .map((p) => ({
      time: Math.floor(new Date(p.time).getTime() / 1000),
      value: p.equity,
    }))
    .filter((p) => Number.isFinite(p.time) && Number.isFinite(p.value));
}

export function BacktestPanel({
  strategyId,
  strategyTimeframe = "1h",
  disableRun = false,
}: {
  strategyId: string;
  strategyTimeframe?: string;
  disableRun?: boolean;
}) {
  const [status, setStatus] = useState<RunStatus>("idle");
  const [, setRunId] = useState<string | null>(null);
  const [metrics, setMetrics] = useState<Record<string, unknown> | null>(null);
  const [equityCurve, setEquityCurve] = useState<EquityPoint[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [bars, setBars] = useState<BarItem[] | undefined>(undefined);
  const [barsUnavailable, setBarsUnavailable] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mountedRef = useRef(true);
  const strategyIdRef = useRef(strategyId);
  const strategyTimeframeRef = useRef(strategyTimeframe);
  const runStrategyIdRef = useRef<string | null>(null);
  const runStrategyTimeframeRef = useRef<string | null>(null);

  strategyIdRef.current = strategyId;
  strategyTimeframeRef.current = strategyTimeframe;

  const stopPolling = useCallback(() => {
    if (pollTimerRef.current) {
      clearInterval(pollTimerRef.current);
      pollTimerRef.current = null;
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      stopPolling();
    };
  }, [stopPolling]);

  const fetchTrades = useCallback(async (rid: string) => {
    const res = await fetch(`/api/backtests/${rid}/trades`);
    if (!res.ok) return;
    const data = await res.json();
    if (Array.isArray(data) && mountedRef.current) setTrades(data as Trade[]);
  }, []);

  const fetchBars = useCallback(async (sid: string, timeframe: string) => {
    const res = await fetch(
      `/api/strategies/${sid}/bars?timeframe=${encodeURIComponent(timeframe)}&limit=500`
    );
    if (!mountedRef.current) return;
    const stillCurrent =
      runStrategyIdRef.current === sid &&
      runStrategyTimeframeRef.current === timeframe;
    if (!stillCurrent) return;
    if (!res.ok) {
      setBars(undefined);
      setBarsUnavailable(true);
      return;
    }
    const data = await res.json();
    if (!mountedRef.current) return;
    if (
      runStrategyIdRef.current !== sid ||
      runStrategyTimeframeRef.current !== timeframe
    )
      return;
    if (Array.isArray(data)) {
      setBars(data as BarItem[]);
      setBarsUnavailable(false);
    }
  }, []);

  const handleRunComplete = useCallback(
    (run: BacktestRun, rid: string) => {
      setMetrics(run.metrics ?? null);
      setStatus("success");

      const logCurve = run.log?.equityCurve;
      if (Array.isArray(logCurve) && logCurve.length > 0) {
        setEquityCurve(logCurve);
      }

      const sid = runStrategyIdRef.current ?? strategyIdRef.current;
      const tf = runStrategyTimeframeRef.current ?? strategyTimeframeRef.current;
      fetchBars(sid, tf);

      const initialCapital = getInitialCapital(run);
      fetchTrades(rid).then(() => {
        if (!mountedRef.current) return;
        if (!Array.isArray(logCurve) || logCurve.length === 0) {
          setTrades((currentTrades) => {
            if (!mountedRef.current) return currentTrades;
            const curve = buildEquityCurveFromTrades(currentTrades, initialCapital);
            setEquityCurve(curve);
            return currentTrades;
          });
        }
      });
    },
    [fetchTrades, fetchBars]
  );

  const pollRun = useCallback(
    async (rid: string) => {
      const res = await fetch(`/api/backtests/${rid}`);
      if (!res.ok || !mountedRef.current) return;
      const run = (await res.json()) as BacktestRun;
      const isDone =
        run.status === "finished" ||
        run.status === "completed" ||
        run.status === "success";
      const isFail = run.status === "error" || run.status === "failed";
      if (isDone) {
        stopPolling();
        if (!mountedRef.current) return;
        if (
          strategyIdRef.current !== runStrategyIdRef.current ||
          strategyTimeframeRef.current !== runStrategyTimeframeRef.current
        ) {
          setRunId(null);
          setStatus("idle");
          return;
        }
        handleRunComplete(run, rid);
        return;
      }
      if (isFail) {
        stopPolling();
        if (mountedRef.current) {
          const errMsg =
            typeof run.log === "object" && run.log && "error" in run.log
              ? String(run.log.error)
              : "Backtest failed";
          setError(errMsg);
          setStatus("error");
        }
      }
    },
    [stopPolling, handleRunComplete]
  );

  const startPolling = useCallback(
    (rid: string) => {
      stopPolling();
      pollTimerRef.current = setInterval(() => pollRun(rid), POLL_INTERVAL_MS);
      pollRun(rid);
    },
    [stopPolling, pollRun]
  );

  const handleRunBacktest = async () => {
    setError(null);
    setRunId(null);
    setMetrics(null);
    setEquityCurve([]);
    setTrades([]);
    setBars(undefined);
    setBarsUnavailable(false);
    setStatus("running");

    try {
      const res = await fetch(`/api/strategies/${strategyId}/backtests`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = (await res.json()) as BacktestRun & {
        error?: string;
        details?: unknown;
      };

      if (!mountedRef.current) return;

      if (!res.ok) {
        const message =
          data.error ??
          (Array.isArray(data.details)
            ? (data.details as { message?: string }[])
                .map((d) => d.message)
                .join("; ")
            : `Request failed (${res.status})`);
        setError(String(message));
        setStatus("error");
        return;
      }

      const run = data as BacktestRun;
      const rid =
        ((data as Record<string, unknown>).runId as string | undefined) ??
        ((data as Record<string, unknown>).id as string | undefined);
      if (!rid) {
        setError("No run id in response");
        setStatus("error");
        return;
      }

      setRunId(rid);
      runStrategyIdRef.current = strategyId;
      runStrategyTimeframeRef.current = strategyTimeframe;

      if (run.status === "completed" && run.metrics != null) {
        handleRunComplete(run, rid);
        return;
      }
      startPolling(rid);
    } catch (err) {
      if (mountedRef.current) {
        setError(err instanceof Error ? err.message : "Network error");
        setStatus("error");
      }
    }
  };

  const totalReturn = metrics?.totalReturnPct as number | undefined;
  const sharpe = metrics?.sharpe as number | undefined;
  const maxDD = metrics?.maxDrawdownPct as number | undefined;
  const winRate = metrics?.winRate as number | undefined;
  const netPnl = metrics?.netPnl as number | undefined;
  const numTrades = metrics?.numberOfTrades as number | undefined;

  return (
    <div className="flex shrink-0 flex-col">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-line px-4 py-2">
        <div className="flex items-center gap-2.5">
          <span
            className="inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold"
            style={{
              background:
                status === "running"
                  ? "var(--accent-bg)"
                  : status === "success"
                  ? "var(--green-bg)"
                  : status === "error"
                  ? "var(--red-bg)"
                  : "var(--surface-2)",
              color:
                status === "running"
                  ? "var(--accent)"
                  : status === "success"
                  ? "var(--green)"
                  : status === "error"
                  ? "var(--red)"
                  : "var(--text-2)",
            }}
          >
            {status === "idle" && "Idle"}
            {status === "running" && "Running…"}
            {status === "success" && "Completed"}
            {status === "error" && "Error"}
          </span>
        </div>
        <button
          type="button"
          onClick={handleRunBacktest}
          disabled={status === "running" || disableRun}
          className="inline-flex items-center gap-1.5 rounded-md bg-profit px-3 py-1.5 text-xs font-semibold text-white shadow-[0_1px_4px_rgba(8,153,129,0.25)] transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {status === "running" ? (
            <>
              <span className="inline-block h-2.5 w-2.5 animate-spin rounded-full border-2 border-white/40 border-t-white" />
              Running…
            </>
          ) : (
            <>
              <svg width="10" height="10" viewBox="0 0 11 11" fill="currentColor">
                <polygon points="2,1 10,5.5 2,10" />
              </svg>
              Run Backtest
            </>
          )}
        </button>
      </div>

      {/* Error */}
      {error && (
        <div className="border-b border-loss/30 bg-loss-bg px-4 py-2 text-xs text-loss">
          {error}
        </div>
      )}

      {/* Chart */}
      {status === "success" && toChartEquity(equityCurve).length > 0 && (
        <div className="border-b border-line">
          {barsUnavailable && (
            <p className="px-4 py-1 text-[11px] text-warn">
              Price bars unavailable; showing equity only.
            </p>
          )}
          <TwoPaneChart
            mode="backtest"
            bars={bars}
            equity={toChartEquity(equityCurve)}
            trades={trades.map((t) => ({
              side:
                t.side.toLowerCase() === "buy" || t.side.toLowerCase() === "long"
                  ? ("long" as const)
                  : ("short" as const),
              entryTime: t.entryTime,
              exitTime: t.exitTime,
              entryPrice: t.entryPrice,
              exitPrice: t.exitPrice,
            }))}
          />
        </div>
      )}

      {/* Metrics */}
      {status === "success" && metrics != null && (
        <div className="grid grid-cols-3 gap-2 border-b border-line px-4 py-3 sm:grid-cols-6">
          <MetricCard
            label="Return"
            value={formatPct(totalReturn)}
            positive={typeof totalReturn === "number" ? totalReturn >= 0 : null}
          />
          <MetricCard
            label="Net PnL"
            value={formatNum(netPnl)}
            positive={typeof netPnl === "number" ? netPnl >= 0 : null}
          />
          <MetricCard
            label="Sharpe"
            value={formatNum(sharpe)}
            positive={typeof sharpe === "number" ? sharpe >= 0 : null}
          />
          <MetricCard label="Max DD" value={formatPct(maxDD)} positive={false} />
          <MetricCard
            label="Win Rate"
            value={formatPct(winRate)}
            positive={typeof winRate === "number" ? winRate >= 50 : null}
          />
          <MetricCard label="Trades" value={formatNum(numTrades, 0)} />
        </div>
      )}

      {/* Trades */}
      {status === "success" && trades.length > 0 && (
        <div className="px-4 py-3">
          <h3 className="mb-2 text-[10px] font-bold uppercase tracking-[0.07em] text-ink-3">
            Trades ({trades.length})
          </h3>
          <div className="overflow-x-auto rounded-lg border border-line">
            <table className="w-full min-w-[600px] text-left text-xs">
              <thead>
                <tr className="border-b border-line bg-surface-alt text-[10px] uppercase text-ink-3">
                  <th className="px-3 py-2 font-semibold">Side</th>
                  <th className="px-3 py-2 font-semibold">Entry Time</th>
                  <th className="px-3 py-2 text-right font-semibold">Entry $</th>
                  <th className="px-3 py-2 font-semibold">Exit Time</th>
                  <th className="px-3 py-2 text-right font-semibold">Exit $</th>
                  <th className="px-3 py-2 text-right font-semibold">Qty</th>
                  <th className="px-3 py-2 text-right font-semibold">PnL</th>
                </tr>
              </thead>
              <tbody>
                {trades.map((t, i) => {
                  const pnlPositive = typeof t.pnl === "number" && t.pnl >= 0;
                  const isLong =
                    t.side.toLowerCase() === "long" ||
                    t.side.toLowerCase() === "buy";
                  return (
                    <tr
                      key={t.id ?? i}
                      className="border-b border-line/60 transition-colors hover:bg-surface-alt"
                    >
                      <td className="px-3 py-1.5">
                        <span
                          className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-semibold"
                          style={{
                            background: isLong ? "var(--green-bg)" : "var(--red-bg)",
                            color: isLong ? "var(--green)" : "var(--red)",
                          }}
                        >
                          {t.side}
                        </span>
                      </td>
                      <td className="px-3 py-1.5 font-mono text-[11px] text-ink-2">
                        {formatTime(t.entryTime)}
                      </td>
                      <td className="px-3 py-1.5 text-right font-mono tabular-nums text-ink-1">
                        {formatNum(t.entryPrice)}
                      </td>
                      <td className="px-3 py-1.5 font-mono text-[11px] text-ink-2">
                        {formatTime(t.exitTime)}
                      </td>
                      <td className="px-3 py-1.5 text-right font-mono tabular-nums text-ink-1">
                        {t.exitPrice != null ? formatNum(t.exitPrice) : "—"}
                      </td>
                      <td className="px-3 py-1.5 text-right font-mono tabular-nums text-ink-2">
                        {formatNum(t.qty, 4)}
                      </td>
                      <td
                        className="px-3 py-1.5 text-right font-mono font-semibold tabular-nums"
                        style={{ color: pnlPositive ? "var(--green)" : "var(--red)" }}
                      >
                        {typeof t.pnl === "number"
                          ? `${t.pnl >= 0 ? "+" : ""}${formatNum(t.pnl)}`
                          : t.pnl}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Empty / running states */}
      {status === "success" && trades.length === 0 && metrics != null && (
        <p className="px-4 py-6 text-center text-xs text-ink-3">
          No trades in this run.
        </p>
      )}

      {status === "idle" && !error && (
        <div className="flex flex-col items-center justify-center gap-1.5 px-4 py-8 text-center">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-profit-bg">
            <span className="text-base text-profit">▷</span>
          </div>
          <div className="text-[13px] font-semibold text-ink-2">
            Run a backtest to see results
          </div>
          <div className="text-[11px] text-ink-3">
            Simulates your strategy against historical bars
          </div>
        </div>
      )}

      {status === "running" && (
        <div className="flex items-center justify-center gap-2 px-4 py-10 text-xs text-ink-2">
          <span className="inline-block h-4 w-4 animate-spin rounded-full border-[2.5px] border-line-strong border-t-profit" />
          Simulating strategy on historical bars…
        </div>
      )}
    </div>
  );
}
